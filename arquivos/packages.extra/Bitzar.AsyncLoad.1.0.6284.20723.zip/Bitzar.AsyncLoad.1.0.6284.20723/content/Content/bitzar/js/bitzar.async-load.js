﻿/* Bitzar Solutions Ltda 
 * Async Module Loading for any kind of content.
 * Just set params data-* and it's done
 * 
 * Parameters accepted:
 * data-async-load = URL to get content and fill inside the body of the div or span or everything else.
 * data-async-interval = time interval for auto-refresh information // Optional, defaul is 30s
 * 
 * Feedback:
 * data-async-state = will be filled with stopped / running / complete and can be used for give visual 
 * effects
 * 
 * Stopped:  will not refresh again
 * Running:  it's in running state
 * Complete: completed the request and ready for next refresh time
 * 
 * http://bitzar.solutions
 */
(function ($) {
    // Request list
    var jqxhrs = [];

    // Method to start looping through any content
    asyncLazyLoad = function () {
        $('[data-async-load]').each(function () {
            lazyLoadContent($(this));
        });
    }

    // Nethod that do the job load data
    lazyLoadContent = function ($ctr) {
        var time = $ctr.data('async-interval');
        if (time == null || time === '' || time == undefined)
            time = 30000;

        var url = $ctr.data('async-load');
        if (url === '' || url === null) {
            $ctr.attr('data-async-state', 'stopped');
        } else {
            // Check running state
            var state = $ctr.attr('data-async-state')
            if (state !== 'running') {

                $ctr.attr('data-async-state', 'running');
                $.get(url, function (data) {
                    $ctr.html(data);
                    $ctr.attr('data-async-state', 'complete');
                });
            }

            // Reeschedule task to load if time is 0
            if (time != 0 && time != '0') {
                setTimeout(function () {
                    lazyLoadContent($ctr);
                }, time);
            }
        }
    }

    // Refresh JQuery Method
    $.fn.asyncLoadRefresh = function () {
        lazyLoadContent($(this));
        return this;
    };

    // Start doing the job
    $(document).ready(function () {
        asyncLazyLoad();
    })

    // Abort all the requests when before page exits
    $(window).bind("beforeunload", function (event) {
        $.each(jqxhrs, function (idx, jqxhr) {
            if (jqxhr != null)
                jqxhr.abort();
        });
    });

    // Helpers to register and unregister new requests that is triggered or finished
    registerJqxhr = function (event, jqxhr, settings) {
        jqxhrs.push(jqxhr);
    }
    unregisterJqxhr = function (event, jqxhr, settings) {
        var idx = $.inArray(jqxhr, jqxhrs);
        jqxhrs.splice(idx, 1);
    }

    $(document).ajaxSend(registerJqxhr);
    $(document).ajaxComplete(unregisterJqxhr);
})($);